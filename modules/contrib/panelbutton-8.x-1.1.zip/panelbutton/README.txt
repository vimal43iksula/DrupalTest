Panel Button

Installation
============

This module requires the core CKEditor module.

1. Download the plugin from http://ckeditor.com/addon/panelbutton at least version 4.5.6.
2. Place the plugin in the root libraries folder (/libraries).
3. Enable Panel Button module in the Drupal admin.